package com.example.interactiveuitrainer;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Switch;
import android.widget.TextView;
import android.webkit.WebView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private TextView txtMessage;
    private Button btnChangeText;
    private EditText edtUserInput;
    private CheckBox chkBold;
    private Switch switchVisibility;
    private ImageView imgExample;
    private RadioGroup radioGroup;
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI elements
        txtMessage = findViewById(R.id.txtMessage);
        btnChangeText = findViewById(R.id.btnChangeText);
        edtUserInput = findViewById(R.id.edtUserInput);
        chkBold = findViewById(R.id.chkBold);
        switchVisibility = findViewById(R.id.switchVisibility);
        imgExample = findViewById(R.id.imgExample);
        radioGroup = findViewById(R.id.radioGroup);
        webView = findViewById(R.id.webView);

        // Button click event
        btnChangeText.setOnClickListener(v -> {
            String userInput = edtUserInput.getText().toString();
            txtMessage.setText(userInput);
        });

        // CheckBox event
        chkBold.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                txtMessage.setTextColor(Color.RED);
            } else {
                txtMessage.setTextColor(Color.BLACK);
            }
        });

        // Switch event
        switchVisibility.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                txtMessage.setVisibility(View.VISIBLE);
            } else {
                txtMessage.setVisibility(View.INVISIBLE);
            }
        });

        // RadioGroup event
        radioGroup.setOnCheckedChangeListener((group, checkedId) -> {
            RadioButton selectedRadioButton = findViewById(checkedId);
            txtMessage.setText("Selected: " + selectedRadioButton.getText());
        });

        // Load a website into WebView
        webView.loadUrl("https://www.healthline.com/fitness");
    }
}