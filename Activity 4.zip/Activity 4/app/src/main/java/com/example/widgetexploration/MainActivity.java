package com.example.widgetexploration;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Switch;
import android.widget.TextClock;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RadioGroup radioGroup = findViewById(R.id.radioGroup);
        final EditText editText = findViewById(R.id.editText);
        final Button button = findViewById(R.id.button);
        final TextClock tClock = findViewById(R.id.textClock);
        final CheckBox cbTransparency = findViewById(R.id.checkBoxTransparency);
        final CheckBox cbTint = findViewById(R.id.checkBoxTint);
        final CheckBox cbReSize = findViewById(R.id.checkBoxReSize);
        final ImageView imageView = findViewById(R.id.imageView);
        Switch switch1 = findViewById(R.id.switch1);
        final TextView textView = findViewById(R.id.textView);
        WebView webView = findViewById(R.id.webView);

        textView.setVisibility(View.INVISIBLE);

        cbTransparency.setOnCheckedChangeListener((buttonView, isChecked) -> {
            imageView.setAlpha(isChecked ? 0.1f : 1f);
        });

        cbTint.setOnCheckedChangeListener((buttonView, isChecked) -> {
            imageView.setColorFilter(isChecked ? Color.argb(150, 255, 0, 0) : Color.argb(0, 0, 0, 0));
        });

        cbReSize.setOnCheckedChangeListener((buttonView, isChecked) -> {
            imageView.setScaleX(isChecked ? 2 : 1);
            imageView.setScaleY(isChecked ? 2 : 1);
        });

        radioGroup.clearCheck();
        radioGroup.setOnCheckedChangeListener((group, checkedId) -> {
            RadioButton rb = findViewById(checkedId);

            if (rb.getId() == R.id.radioButtonLondon) {
                tClock.setTimeZone("Europe/London");
            } else if (rb.getId() == R.id.radioButtonBeijing) {
                tClock.setTimeZone("Etc/GMT-8");
            } else if (rb.getId() == R.id.radioButtonNewYork) {
                tClock.setTimeZone("America/New_York");
            }
        });

        button.setOnClickListener(v -> textView.setText(editText.getText()));

        switch1.setOnCheckedChangeListener((buttonView, isChecked) -> {
            textView.setVisibility(isChecked ? View.VISIBLE : View.INVISIBLE);
        });

        webView.loadUrl("https://gamecodeschool.com");
    }
}
