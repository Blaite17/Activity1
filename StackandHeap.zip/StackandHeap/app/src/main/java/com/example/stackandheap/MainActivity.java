package com.example.stackandheap;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private int value = 0;
    private float size;

    private Button btnAdd, btnTake, btnGrow, btnShrink, btnReset, btnHide;
    private TextView txtValue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // Initialize UI elements
        btnAdd = findViewById(R.id.btnAdd);
        btnTake = findViewById(R.id.btnTake);
        txtValue = findViewById(R.id.txtValue);
        btnGrow = findViewById(R.id.btnGrow);
        btnShrink = findViewById(R.id.btnShrink);
        btnReset = findViewById(R.id.btnReset);
        btnHide = findViewById(R.id.btnHide);

        // Set Click Listeners
        btnAdd.setOnClickListener(this);
        btnTake.setOnClickListener(this);
        btnGrow.setOnClickListener(this);
        btnShrink.setOnClickListener(this);
        btnReset.setOnClickListener(this);
        btnHide.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v == btnAdd) {
            value++;
            txtValue.setText(String.valueOf(value));
        } else if (v == btnTake) {
            value--;
            txtValue.setText(String.valueOf(value));
        } else if (v == btnReset) {
            value = 0;
            txtValue.setText(String.valueOf(value));
        } else if (v == btnHide) {
            if (txtValue.getVisibility() == View.VISIBLE) {
                txtValue.setVisibility(View.INVISIBLE);
                btnHide.setText("SHOW");
            } else {
                txtValue.setVisibility(View.VISIBLE);
                btnHide.setText("HIDE");
            }
        } else if (v == btnGrow) {
            size = txtValue.getTextScaleX(); // Correct method call
            txtValue.setTextScaleX(size + 1);
        } else if (v == btnShrink) {
            size = txtValue.getTextScaleX(); // Correct method call
            txtValue.setTextScaleX(size - 1);
        }
    }
}
