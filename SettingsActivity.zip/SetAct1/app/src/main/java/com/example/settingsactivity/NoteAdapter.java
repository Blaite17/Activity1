package com.example.settingsactivity;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class NoteAdapter extends RecyclerView.Adapter<NoteAdapter.ViewHolder> {

    private final List<Note> mNotes;
    private final Context mContext;
    private boolean mShowDividers = true; // default value

    public NoteAdapter(Context context, List<Note> notes) {
        mContext = context;
        mNotes = notes;
    }

    public void setShowDividers(boolean showDividers) {
        mShowDividers = showDividers;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.list_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Note currentNote = mNotes.get(position);

        // Build the type text based on note flags.
        StringBuilder typeBuilder = new StringBuilder();
        if (currentNote.isIdea()) {
            typeBuilder.append(mContext.getString(R.string.idea_text));
        }
        if (currentNote.isTodo()) {
            if (typeBuilder.length() > 0) typeBuilder.append(", ");
            typeBuilder.append(mContext.getString(R.string.todo_text));
        }
        if (currentNote.isImportant()) {
            if (typeBuilder.length() > 0) typeBuilder.append(", ");
            typeBuilder.append(mContext.getString(R.string.important_text));
        }
        String typeText = typeBuilder.length() > 0 ? typeBuilder.toString() : "None";

        holder.textType.setText(typeText);
        holder.textTitle.setText(currentNote.getTitle());
        holder.textDescription.setText(currentNote.getDescription());

        // Set divider visibility based on the setting
        holder.divider.setVisibility(mShowDividers ? View.VISIBLE : View.GONE);

        // Set click listener to show note details
        holder.itemView.setOnClickListener(v -> {
            DialogShowNote dialog = new DialogShowNote();
            dialog.sendNoteSelected(currentNote);
            dialog.show(((MainActivity) mContext).getSupportFragmentManager(), "");
        });
    }

    @Override
    public int getItemCount() {
        return mNotes.size();
    }

    // ViewHolder inner class
    public static class ViewHolder extends RecyclerView.ViewHolder {
        public final TextView textType;
        public final TextView textTitle;
        public final TextView textDescription;
        public final View divider;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textType = itemView.findViewById(R.id.textType);
            textTitle = itemView.findViewById(R.id.textTitle);
            textDescription = itemView.findViewById(R.id.textDescription);
            divider = itemView.findViewById(R.id.divider);
        }
    }
}
